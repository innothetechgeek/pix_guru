<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
    </style>
</head>
<body>
    <div class="container"> 
		<h2>Membership</h2>
		
		<?php if($memberships) { ?>
			<?php foreach($memberships as $membership) { ?>
				<div class="col-md-3" style="    height: 100%; border-radius: 17px; padding: 5% 2%; color: #222; margin: 0; background-color: #<?php echo $membership->color;?>">
					<?php $type = explode("_", $membership->type); ?>
					<h3 class="member-text"><?php echo $type[0];?> <span><?php echo $type[1];?></span></h3>
					
					<h4 class="member-price">R<?php echo $membership->price; ?></h4>
					<p class="member-btn"><a class="member-btn " href="<?php echo base_url('register?membership='.$membership->type);?>" class="btn btn-primary">Join today</a></p>
				</div>
			<?php } ?>
		<?php } ?>
		
		<?php /* ?>
		<div class="col-md-3" style="height: 250px; background-color: #BFDFEA">
			<h3>Beginner</h3>
			<h3>Annual</h3>
			<h4>R99</h4>
			<p><a href="<?php echo base_url('register?membership=beginner_annual');?>" class="btn btn-primary">Join today</a></p>
		</div>
		<div class="col-md-3" style="height: 250px; background-color: #9CC6D4">
			<h3>Beginner</h3>
			<h3>Monthly</h3>
			<h4>R12</h4>
			<p><a href="<?php echo base_url('register?membership=beginner_monthly');?>" class="btn btn-primary">Join today</a></p>
		</div>
		<div class="col-md-3" style="height: 250px; background-color: #EAD8BF">
			<h3>Advanced</h3>
			<h3>Annual</h3>
			<h4>R299</h4>
			<p><a href="<?php echo base_url('register?membership=advanced_annual');?>" class="btn btn-primary">Join today</a></p>
		</div>
		<div class="col-md-3" style="height: 250px; background-color: #D8C09E">
			<h3>Advanced</h3>
			<h3>Monthly</h3>
			<h4>R29</h4>
			<p><a href="<?php echo base_url('register?membership=advanced_monthly');?>" class="btn btn-primary">Join today</a></p>
		</div>
		<?php */ ?>
		
    </div>    
</body>
</html>