
<div class="container">

	<img src="assets/images/pix-guru/slides/3.jpg" alt="">
	<!-- <div class="home-slide1 owl-carousel nav-style1" data-items="1" data-nav="true" data-dots="false" data-loop="true" data-autoplay="true">
		<img src="images/slides/3.jpg" alt="">
		<img src="images/slides/3.jpg" alt="">
		<img src="images/slides/3.jpg" alt="">
	</div> -->
	
	<div class="text-center heading">
	    <h1><span>DO NOT WAIT!</span> BECOME A MEMBER NOW!</h1>
	</div>

	<div class="section-about-home ">
        <div class="container">
            <div class="text-center style7">
            	<div class="row">
            		<div class="col-md-6">
            			<br>
            			   <span class="sub-title" style=" color: #c99947;">Welcome to Pix-Guru</span>
			                <h3>READ MORE ABOUT US</h3>


			            <div class="row">
			                <div class="col-sm-10 col-sm-offset-1 text-center">
			                    <p>
								The photographers that will critique your photos, are all established professional photographers who share more than 140 years of experience between them – they have travelled all over the world taking some breathtaking photos and experiencing many amazing cultures, people and animals.<br>
								</p>

								<blockquote class="style2 margin-bottom-10">
							    With our help you can learn everything you need to know about photography and be the photographer you always wanted to be!
							    </blockquote>
								
			                </div>
			            </div>
			            <div class="text-center GreatVibes">
			            </div>
            		</div>

            		<div class="col-md-6">

            			<a class="banner-opacity" href="#"><img src="assets/images/pix-guru/home-gallery/4.JPG" alt=""></a>
            		</div>

            	</div>
  			</div>
        </div>
    </div>



</div>

	<div class="row border-gold-line">
	    
    		<div class="col-sm-12  quote">
    			<div class="kt-banner block-kt-banner style1" >
    				<div class="text-center">
    				    <div class="container">
        					<h3 class="title">Pix-Guru</h3>
        					<div class="subtitle">
        					    Thousands of photography training programs can be bought or followed on-line today.  
        					    But, nowhere will you find a website dedicated to giving feedback on your photos!  
        					    This is the aim of Pix-Guru.  To give you honest and creative feedback enabling you to become a PIX-GURU!   
        					    If you apply our recommendations, you will soon see positive results in your photography! 
        					    To maintain a high standard of feedback, we unfortunately can only accommodate a small number of clients.  
        					    To guarantee a place, you need to act immediately!  </div>
        					<a class="banner-button" href="#">become a member</a>
        				</div>
    				</div>
    			</div>
    		</div>
	</div>

	<div class="gallery-section  ">
		<div class="row margin-0">
			<div class="col-sm-4 padding-0">
				<blockquote class="style3 margin-bottom-10">
					<b>Play & Learn</b> – risk free:  Grow your confidence and your photography portfolio with our assistance
				</blockquote>
			</div>
			<div class="col-sm-4 padding-0">
				<div class="kt-banner block-kt-banner style2" data-background="assets/images/pix-guru/quote/1.jpg" data-position="center" data-height="300" data-positionright="65px" data-positionleft="65px">
					<a href="#" class="bg-image"></a>
				</div>
			</div>
			<div class="col-sm-4 padding-0">
				<blockquote class="style3 margin-bottom-10">
					Join members in the <b>Pix-Guru</b> community and become a better photographer……
				</blockquote>
			</div>
		</div>
		<div class="row margin-0">
			<div class="col-sm-4 padding-0" style="padding: 0 0.1% 0 0 !important;">
				<div class="kt-banner block-kt-banner style5" data-background="assets/images/pix-guru/quote/3.JPG" data-height="300" data-positiontop="60px" data-position="center" data-positionleft="0px" data-positionright="0px">
					<a href="#" class="bg-image"></a>
					<div class="banner-content text-center">
						<div class="video video-lightbox">
							<a href="#" class="link-lightbox button-play" data-videoid="134060140" data-videosite="vimeo"></a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-sm-4 padding-0">
				<blockquote class="style3 margin-bottom-10">
					
					<b>Photography feedback/critique for everyone</b> – beginner, intermediate and professional photographers

				</blockquote>
			</div>
			<div class="col-sm-4 padding-0">
				<div class="kt-banner block-kt-banner style2" data-background="assets/images/pix-guru/quote/2.JPG" data-position="center" data-height="300" data-positionright="65px" data-positionleft="65px">
					<a href="#" class="bg-image"></a>
				</div>
			</div>
		</div>
		<div class="row margin-0" style="background: #0d0d0d;">
			<div class="col-sm-4 padding-0">
				<div class="kt-banner block-kt-banner tempi style1" >
					<div class="text-center">
						<h3 class="title">Stay on top!</h3>
						<div class="subtitle">Stay on top of the buzz of an ever-changing photography world with our assistance!</div>
					</div>
				</div>
			</div>
			<div class="col-sm-8 padding-0">
				<div class="mobi kt-banner block-kt-banner style2" data-background="assets/images/pix-guru/quote/5.JPG" data-position="center" data-height="300" data-positionright="65px" data-positionleft="65px">
					<a href="#" class="bg-image"></a>
				</div>
			</div>
		</div>
	</div>

    

<div class="container">	
	<div class="newsletter-section">
		<!--<div>-->
		<!--	<div class="row">-->
		<!--		<div class="col-sm-12 col-md-7">-->
		<!--			<div class="video video-lightbox">-->
		<!--				<img src="images/newsletter/newsletter.JPG" alt="">-->
		<!--				<div class="overlay"></div>-->
		<!--				<a href="#"  class="link-lightbox button-play" data-videoid="134060140" data-videosite="vimeo"></a>-->
		<!--			</div>-->
		<!--		</div>-->
		<!--		<div class="col-sm-12 col-md-5">-->
		<!--			<div class="newsletter">-->
	 <!--                   <div class="section-title text-center"><h3>NEWSLETTER</h3></div>-->
	 <!--                   <i class="newsletter-info">Sign up for Our Newsletter</i>-->
	 <!--                   <form class="form-newsletter">-->
	 <!--                     <input type="text" name="newsletter" placeholder="Your email address here..." value="">-->
	 <!--                     <span><button class="newsletter-submit" type="submit">SIGNUP</button></span>-->
	 <!--                   </form>-->
	 <!--               </div>-->
		<!--		</div>-->
		<!--	</div>-->
		<!--</div>-->
		<div class="margin-top-60">
			<div class="row">
				<div class="col-sm-12 col-md-4">
	                <div class="element-icon style2">
						<div class="icon"><i class="flaticon flaticon-origami28"></i></div>
						<div class="content">
							<h4 class="title">IMPROVE YOUR SKILLS</h4>
						</div>
					</div>
				</div>
				<div class="col-sm-12 col-md-4">
	                <div class="element-icon style2">
						<div class="icon"><i class="flaticon flaticon-curvearrows9"></i></div>
						<div class="content">
							<h4 class="title">PHOTOGRAPHY REVIEWING</h4>
						</div>
					</div>
				</div>
				<div class="col-sm-12 col-md-4">
	                <div class="element-icon style2">
						<div class="icon"><i class="flaticon flaticon-headphones54"></i></div>
						<div class="content">
							<h4 class="title">ONLINE SUPPORT</h4>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

</html>