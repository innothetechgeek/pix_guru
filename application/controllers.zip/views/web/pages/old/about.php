	<div class="hero-wrap hero-bread" style="background-image: url('assets/images/bg_6.jpg');">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-0 bread"><b>About Us</b></h1>
          </div>
        </div>
      </div>
    </div>

    <div class="goto-here"></div>


    <section class="ftco-section ftco-no-pb ftco-no-pt">
		<div class="container">
			<div class="row">
				<div class="col-md-12 py-5 wrap-about pb-md-5 ftco-animate">
		          <div class="heading-section-bold mb-5 mt-md-5">
		          	<div class="ml-md-0">
			            <h2 class="mb-4"><span>So where did it all start</span></h2>
		            </div>
		          </div>
                    <div class="pb-md-5">
						<p>White tippex used as french white nail polish in the classroom as a result of detention letters. 
						It followed with school hostel “pamper parties” and always being late for a school dance. Then in grade 11, 
						I started job shadowing for a school subject in a hair and beauty salon (Tosca in Tyger Valley Center). 
						It followed a school holiday and occasional weekend casual job.<br><br>

                        I met my first nail educator Erika Breytenbach at Caprice Academy in January 2005 where I completed an 
                        Acrylic Nail Education Course conducted by EzFlow Nail Systems. Completed a course in Bio Sculpture Gel 
                        Nail Care 2006. Through my first job at Dream nails in March 2005, I completed a course in all nail systems 
                        and Qualified through Nail System International in September 2007.<br><br>
                        
                        In January 2009 I met Sanmarie Botha and completed pedicures and manicures in Achievement award of 
                        advanced Spa Ritual Training at Logica Beauty Supplies Working at Ooh-La-La Nail Bar. My Job after 
                        that followed at Sorbet Group and training in Gelish, Acrylic, manicure & pedicure via Harmony. 
                        Dermalogica and Environ skincare training and exam. In 2010 I worked at Dion Lifestyle Hair Nail and Beauty studio.<br><br>
                        
                        I took my work experience and returned to my first educator Erika Breytenbach and worked for her daughter, 
                        Bertha Shannon Leonard in 2011 (SAQA qualified assessor and moderator). I worked for her for 5 years with 
                        the best work experience and training experience in my career. Nailsforu distributors, Capri Beauty a Capri 
                        Academy Clinic. Full Nail technology training and exam (Nailsforu).
					</div>
				</div>
			</div>
		</div>
	</section>

    <section class="ftco-section ftco-section-more img" style="background-image: url(assets/images/bg_5.jpg);">
    	<div class="container">
    		<div class="row justify-content-center mb-3 pb-3">
	          <div class="col-md-12 heading-section ftco-animate">
	          	<h2>BE YOU</h2>
	          </div>
        	</div>
    	</div>
    </section>
