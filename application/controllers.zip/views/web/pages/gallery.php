
	<div class="container">

		<ul class="kt-popup-gallery lookbook-list row">
            <li class="item col-sm-4 col-md-4">
                <a href="images/gallery/pix-guru-1.JPG"><img src="assets/images/pix-guru/gallery/pix-guru-1.JPG" alt="Pix-Guru Photography Training"></a>
            </li>
            <li class="item col-sm-4 col-md-4">
                <a href="assets/images/pix-guru/gallery/pix-guru-2.jpg"><img src="assets/images/pix-guru/gallery/pix-guru-22.jpg" alt="Pix-Guru Photography Training"></a>
            </li>
            <li class="item col-sm-4 col-md-4">
                <a href="assets/images/pix-guru/gallery/pix-guru-3.JPG"><img src="assets/images/pix-guru/gallery/pix-guru-33.jpg" alt="Pix-Guru Photography Training"></a>
            </li>
            <li class="item col-sm-4 col-md-4">
                <a href="assets/images/pix-guru/gallery/pix-guru-4.JPG"><img src="assets/images/pix-guru/gallery/pix-guru-44.jpg" alt="Pix-Guru Photography Training"></a>
            </li>
            <li class="item col-sm-4 col-md-4">
                <a href="assets/images/pix-guru/gallery/pix-guru-5.JPG"><img src="assets/images/pix-guru/gallery/pix-guru-55.jpg" alt="Pix-Guru Photography Training"></a>
            </li>
            <li class="item col-sm-4 col-md-4">
                <a href="assets/images/pix-guru/gallery/pix-guru-6.jpg"><img src="assets/images/pix-guru/gallery/pix-guru-66.jpg" alt="Pix-Guru Photography Training"></a>
            </li>
            <li class="item col-sm-4 col-md-4">
                <a href="assets/images/pix-guru/gallery/pix-guru-7.JPG"><img src="assets/images/pix-guru/gallery/pix-guru-77.jpg" alt="Pix-Guru Photography Training"></a>
            </li>
            <li class="item col-sm-4 col-md-4">
                <a href="assets/images/pix-guru/gallery/pix-guru-8.JPG"><img src="assets/images/pix-guru/gallery/pix-guru-88.jpg" alt="Pix-Guru Photography Training"></a>
            </li>
            <li class="item col-sm-4 col-md-4">
                <a href="assets/images/pix-guru/gallery/pix-guru-9.JPG"><img src="assets/images/pix-guru/gallery/pix-guru-99.jpg" alt="Pix-Guru Photography Training"></a>
            </li>
            <li class="item col-sm-4 col-md-4">
                <a href="assets/images/pix-guru/gallery/pix-guru-10.JPG"><img src="assets/images/pix-guru/gallery/pix-guru-1010.jpg" alt="Pix-Guru Photography Training"></a>
            </li>
            <li class="item col-sm-4 col-md-4">
                <a href="assets/images/pix-guru/gallery/pix-guru-11.JPG"><img src="assets/images/pix-guru/gallery/pix-guru-1111.jpg" alt="Pix-Guru Photography Training"></a>
            </li>
            <li class="item col-sm-4 col-md-4">
                <a href="assets/images/pix-guru/gallery/pix-guru-12.JPG"><img src="assets/images/pix-guru/gallery/pix-guru-1212.jpg" alt="Pix-Guru Photography Training"></a>
            </li>
        </ul>

	</div>
