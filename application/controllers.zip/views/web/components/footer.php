	<footer class="footer">
		<div class="footer-top">
			<div class="container">
				<div class="row flex-flow">
					<div class="col-sm-12 col-md-4 footer-sidebar">
						<div class="widget contact-info">
							<span class="text-primary">Talk to Us Now !</span>
							<h3 class="widget-title">Contact Us</h3>
							<div class="content">
								<p class="address">Cape Town</p>
								<p class="phone"><i class="fa fa-email"></i>info@pix-guru.com</p>
							</div>
						</div>
					</div>
					<div class="col-sm-12 col-md-4 footer-sidebar">
						<div class="widget our-service">
							<span class="text-primary">Talk to Us Now !</span>
							<h3 class="widget-title">OUR SERVICES</h3>
							<div class="content">
								<ul>
									<li><a href="<?php echo base_url('about');?>">About us</a></li>
									<li><a href="<?php echo base_url('critique');?>">Critique</a></li>
									<li><a href="<?php echo base_url('gallery');?>">Gallery</a></li>
									<li><a href="<?php echo base_url('contact');?>">Contact Us</a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-sm-12 col-md-4 footer-sidebar">
						<div class="widget widget_social">
							<span class="text-primary">Talk to Us Now !</span>
							<h3 class="widget-title">FOLLOW US</h3>
							<div class="content">
								<div class="social">
			                        <a href="#"><i class="fa fa-facebook"></i></a>
			                        <a href="#"><i class="fa fa-instagram"></i></a>
			                        <a href="#"><i class="fa fa-pinterest"></i></a>
			                    </div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="footer-bottom">
			<div class="container">
			<div class="payment">
				<div class="head"><span>COPYRIGHT 2020 / JNZ SOFTWARE</span></div>
			</div>
			</div>
		</div>

	</footer>
	
	<a href="#" class="scroll_top" title="Scroll to Top" style="display: block;"><i class="fa fa-arrow-up"></i></a>
	<script src="<?php echo base_url('assets/js/pix-guru/jquery-2.1.4.min.js');?>"></script>
	<script src="<?php echo base_url('assets/js/pix-guru/bootstrap.min.js');?>"></script>
	<script src="<?php echo base_url('assets/js/pix-guru/owl.carousel.min.js');?>"></script>
	<script src="<?php echo base_url('assets/js/pix-guru/chosen.jquery.min.js');?>"></script>
	<script src="<?php echo base_url('assets/js/pix-guru/Modernizr.js');?>"></script>
	<script src="<?php echo base_url('assets/js/pix-guru/query-ui.min.js');?>"></script>
	<script src="<?php echo base_url('assets/js/pix-guru/lightbox.min.js');?>"></script>
	<script src="<?php echo base_url('assets/js/pix-guru/imagesloaded.pkgd.min.js');?>"></script>
	<script src="<?php echo base_url('assets/js/pix-guru/isotope.pkgd.min.js');?>"></script>
	<script src="<?php echo base_url('assets/js/pix-guru/jquery.mCustomScrollbar.concat.min.js');?>"></script>
	
	<script src="<?php echo base_url('assets/js/pix-guru/jquery.parallax-1.1.3.js');?>"></script>
	<script src="<?php echo base_url('assets/js/pix-guru/jquery.magnific-popup.min.js');?>"></script>
	<script src="<?php echo base_url('assets/js/pix-guru/masonry.js');?>"></script>
	<script src="<?php echo base_url('assets/js/pix-guru/functions.js');?>"></script>
</body>
</html>
	

 