<?php
  /*
    $variablesarray = explode("&",urldecode($_SERVER['QUERY_STRING']));
    foreach($variablesarray as $variable)
    {
        $variable = htmlentities($variable, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        parse_str($variable);
        $variable = "";
    }
    
    
    $productmenu = "";
    $query = "SELECT id, heading FROM products ORDER BY heading ASC";
    if($result = mysqli_query($link, $query))
    {
        while ($row = mysqli_fetch_row($result))
        {
            $menuid = $row[0];
            $menutitle = $row[1];
            
            $productmenu .= '<a class="dropdown-item" href="product.php?id='.$menuid.'">'.$menutitle.'</a>';
            
            $menuid = $menutitle = "";
        }
        mysqli_free_result($result);
    }
    */
    $productmenu = "";
    $products = $this->db->order_by('heading','asc')->get('products')->result();
    foreach($products as $product){
      $productmenu .= '<a class="dropdown-item" href="'.base_url("web/services/{$product->id}").'">'.$product->heading.'</a>';
    }
    $servicesmenu = "";
    $services = $this->db->order_by('heading','asc')->get('services')->result();
    foreach($services as $service){
      $servicesmenu .= '<a class="dropdown-item" href="'.base_url("web/products/{$service->id}").'">'.$service->heading.'</a>';
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8">
    <title>PIX-GURU - About Us</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/pix-guru/animate.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/pix-guru/bootstrap.min.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/pix-guru/font-awesome.min.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/pix-guru/owl.carousel.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/pix-guru/chosen.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/pix-guru/lightbox.min.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/pix-guru/pe-icon-7-stroke.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/pix-guru/jquery.mCustomScrollbar.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/pix-guru/magnific-popup.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/pix-guru/style.css');?>">
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Montserrat">
    <link href='https://fonts.googleapis.com/css?family=Playfair+Display:400italic,400,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto:300,100,100italic,300italic,400,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Oswald:400,300,700' rel='stylesheet' type='text/css'>
</head>
<body class="">
	<div id="box-mobile-menu" class="box-mobile-menu full-height full-width">
		<div class="box-inner">
			<span class="close-menu"><span class="icon pe-7s-close"></span></span>
		</div>
	</div>
	<header id="header" class="header style2">
		<div class="main-header">
			<div class="container">
				<div class="main-menu-wapper">
					<div class="row">
						<div class="col-sm-12 col-md-3 logo-wapper">
							<div class="logo">
								<a href="index.html"><img src="http://pix-guru.jnztesting.co.za/assets/images/pix-guru/logos/logo.png" alt="Pix-Guru"></a>
							</div>
						</div>
						<div class="col-sm-12 col-md-9 menu-wapper">
							<ul class="boutique-nav main-menu clone-main-menu">                                      
								<li class=" active menu-item-has-children item-megamenu">
									<a href="<?php echo base_url('index');?>">Home</a>
								</li>
								<li class=" menu-item-has-children item-megamenu">
									<a href="<?php echo base_url('critique');?>">Critique</a>
								</li>
								<li class="menu-item-has-children item-megamenu">
									<a href="<?php echo base_url('about');?>">About Us</a>
								</li>
								<li class=" menu-item-has-children item-megamenu">
									<a href="<?php echo base_url('gallery');?>">Gallery</a>
								</li>
								<li class=" menu-item-has-children item-megamenu">
									<a href="<?php echo base_url('contact');?>">Contact Us</a>
								</li>
							</ul>
							<span class="mobile-navigation"><i class="fa fa-bars"></i></span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
	<!-- ./Header -->



    <!-- END nav -->