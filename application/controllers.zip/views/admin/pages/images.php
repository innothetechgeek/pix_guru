<?php if(isset($view)){?>
    
    <center>
        <div class="container my-view">
         <div class="row">
            <div class="col-md-6">
                <img style="width: 100%; margin: 0 auto" src="<?=base_url('assets/images/test/'.$image)?>">
                <table class="my-img-table" style="margin: 0;     width: 100%;">
     
                     <?php if($image){ ?><?php } ?>
                     <tr><td class="golden">WHO TOOK THE PHOTO</td><td><p><?=$who?></p></td></tr>
                     <tr><td class="golden">AUTHOR</td><td><p>Pix-Guru</p></td></tr>
                     <tr><td class="golden">DATE</td><td><p><?=$timestamp?></p></td></tr>
                     <tr><td class="golden">PHOTO NAME/NUMBER</td><td><p><?=$number?></p></td></tr>
                     <tr><td class="golden">WHERE WAS THE PHOTO TAKEN</td><td><p><?=$taken?></p></td></tr>
                     <tr><td class="golden">TIME OF DAY IT WAS TAKEN</td><td><p><?=$time?></p></td></tr>
                     <tr><td class="golden">INTENDED AUDIENCE/USE</td><td><p><?=$audience?></p></td></tr>
                     <tr><td class="golden">WHY TAKEN</td><td><p><?=$why?></p></td></tr>
                     <tr><td class="golden">RELATIONSHIP WITH SUBJECT</td><td><p><?=$relationship?></p></td></tr>
                     <tr><td class="golden">MANIPULATED/EDITED</td><td><p><?=$edit?></p></td></tr>
                     <tr><td class="golden">GENRE</td><td><p><?=$genre?></p></td></tr>
                     
                </table>
            </div>
             <div class="col-md-6">
                 <div class="bg-message">
                <div class="col-md-12">
                <form action="/admin/add_message" method="post">
                    <table class="my-feedback-table">
                         
                         <tr><td valign='top' class="feedback-heading ">FEEDBACK</td></tr>
                         <tr><td class="feedback"><textarea name="message" class="save-field" cols="30" rows="12"></textarea></td></tr>
                         <tr><td>
                            <input type="hidden" name="type" value="<?=$type?>">
                            <input type="hidden" name="id" value="<?=$id?>">
                            <input type="submit" class="save-btn reply-btn " name="submit" value="SAVE" />
                        </td></tr>
                         
                     </table>
                 </form>
            </div>
                <?php if(isset($messages)){
                    foreach($messages as $message){ ?>
                        
                        <div><p class="pix-guru-chat"><?=$message['timestamp']?> <?=$message['username']?></p></div>
                        <div><p class="message"><?=$message['message']?></p></div>
                        
                <?php } } ?>
                </div>
             </div>
         </div>
        </div>
     </center>
    
<?php }else{  ?>

    <?php if($type == 1 || $type == 2){
    
    $title = "BEGINNERS"; if($type == 2) $title = "ADVANCED";
    ?>
    
    <center>
        <h1 class="prod-header"><?=$title?></h1><table style="width: 98%">
        <?php
        echo ' <div class="product-details welcome">
                <div class="row">';
        
            foreach ($images as $image)
            {
                echo '
                <div class="col-md-3 prod-left">
                <div class="my-member" style="cursor: pointer;" onclick="location.href=\''.base_url('admin/images/'.$type.'/'.$image->id).'\'">
                <h3><i class="fa-icon fa fa-clock"></i>'.date("d/m/Y H:i",strtotime($image->timestamp)).'</h3>
                <div class="my-img">
                <img src="'.base_url('assets/images/test/'.$image->image).'" width="100%" >
                </div>
                </div>
                </div>
                ';
            }
            echo '</div></div>';
        ?>
    
    </center>
    <?php } ?>
        
<?php } ?>