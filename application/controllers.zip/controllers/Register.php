<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {

	public function index()
	{
	    //if(!$_GET['membership']) redirect(web/membership);
		
		$data['username'] = '';
		$data['email'] = '';
		$data['username_err'] = '';
		$data['email_err'] = '';
		$data['password_err'] = '';
		$data['confirm_password_err'] = '';
		$data['membership'] = $_GET['membership'];
		$this->load->view('register', $data);
	}
	
}
