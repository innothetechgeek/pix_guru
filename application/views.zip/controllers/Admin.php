<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$data['type'] = '';
		$this->load->view('admin/components/sidebar');
		$this->load->view('admin/pages/home',$data);
		$this->load->view('admin/components/footer');
	}


	
	
	public function services($id = null, $type = 'service')
	{
		$data['id'] = ($id>0)?$id:'';
		$data['type'] = $type;
		$data['heading'] = '';
		$data['price'] = '';
		$data['extra'] = '';
		$data['description'] = '';
		$data['directions'] = '';
		$data['safe'] = '';
		$data['work'] = '';
		$data['result'] = '';
		$data['images'] = '';
		
		if($id > 0){
			$service = $this->db->where('id',$id)->get('services')->row();
			$data['heading'] = $service->heading;
			$data['price'] = $service->price;
			$data['extra'] = $service->extra;
			$data['description'] = $service->description;
			$data['directions'] = $service->directions;
			$data['safe'] = $service->safe;
			$data['work'] = $service->work;
			$data['result'] = $service->result;
			$data['images'] = $service->images;
		}else{
			$data['services'] = $this->db->get('services')->result();
		}
		
		$this->load->view('admin/components/sidebar');
		$this->load->view('admin/pages/services',$data);
		$this->load->view('admin/components/footer');
	}

	public function vouchers($id = null, $type = 'voucher')
	{
		$data['id'] = ($id>0)?$id:'';
		$data['method'] = $type;
		$data['title'] = '';
		$data['type'] = '';
		$data['price'] = '';
		
		if($id > 0){
			$voucher = $this->db->where('id',$id)->get('vouchers')->row();
			$data['title'] = $voucher->title;
			$data['type'] = $voucher->type;
			$data['price'] = $voucher->price;
		}else{
			$data['vouchers'] = $this->db->get('vouchers')->result();
		}
		
		$this->load->view('admin/components/sidebar');
		$this->load->view('admin/pages/vouchers',$data);
		$this->load->view('admin/components/footer');
	}

	public function voucher_orders($id = null)
	{
		$data['id'] = $id?$id:'';
		$data['type'] = 'voucher';
		$data['vouchers'] = $this->db->get('voucher_orders')->result();
		$this->load->view('admin/components/sidebar');
		$this->load->view('admin/pages/voucher',$data);
		$this->load->view('admin/components/footer');
	}

	public function emails()
	{
		$data['emails'] = $this->db->get('emails')->result();
		$this->load->view('admin/components/sidebar');
		$this->load->view('admin/pages/emails',$data);
		$this->load->view('admin/components/footer');
	}


	public function add_service(){
		$data = $this->input->post();
		unset($data['submit']);
		
		if (!empty($_FILES['images']['name'])) {
            $val = $this->uploadImage('images','test'); //products/gallery
            //$val == TRUE || redirect('admin/products');
            if($val == TRUE) $data['images'] = $val['path'];
        }
        
        if(empty($data['images'])) unset($data['images']);

		$this->db->insert('services',$data);
		//redirect($_SERVER['HTTP_REFERER']);
		redirect('admin/services');
	}

	public function update_service($id = null){
		if($id > 0){
			$data = $this->input->post();
			unset($data['submit']);
			
			if (!empty($_FILES['images']['name'])) {
				$val = $this->uploadImage('images','test'); //products/gallery
				//$val == TRUE || redirect('admin/products');
				if($val == TRUE) $data['images'] = $val['path'];
			}
			
			if(empty($data['images'])) unset($data['images']);
			
			$query = $this->db->where('id',$id)->update('services', $data);
			//redirect($_SERVER['HTTP_REFERER']);
			redirect('admin/services');
		}
	}

	public function delete_service($id = null){
		if($id > 0){
			$query = $this->db->where('id',$id)->delete('services');
			if($query){
				redirect($_SERVER['HTTP_REFERER']);
			}
		}
	}


	public function add_voucher(){
		$data = $this->input->post();
		unset($data['submit']);
		
		/*if (!empty($_FILES['images']['name'])) {
            $val = $this->uploadImage('images','vouchers');
            //$val == TRUE || redirect('admin/vouchers');
            if($val == TRUE) $data['images'] = $val['path'];
        }
        
        if(empty($data['images'])) unset($data['images']);
        */
		$data['status'] = 1;
		$this->db->insert('vouchers',$data);
		//redirect($_SERVER['HTTP_REFERER']);
		redirect('admin/vouchers');
	}

	public function update_voucher($id = null){
		if($id > 0){
			$data = $this->input->post();
			unset($data['submit']);
			
			/*if (!empty($_FILES['images']['name'])) {
				$val = $this->uploadImage('images','vouchers');
				//$val == TRUE || redirect('admin/vouchers');
				if($val == TRUE) $data['images'] = $val['path'];
			}
			
			if(empty($data['images'])) unset($data['images']);
			*/
			
			$query = $this->db->where('id',$id)->update('vouchers', $data);
			//redirect($_SERVER['HTTP_REFERER']);
			redirect('admin/vouchers');
		}
	}

	public function change_voucher_status($action,$id = null){
		if($id > 0){
			$status = ($action=='Enable')? 1:0;
			$query = $this->db->where('id',$id)->update('vouchers', array('status' => $status));
			if($query){
				redirect($_SERVER['HTTP_REFERER']);
			}
		}
	}

	function uploadImage($field, $type){
		$config['upload_path'] = './assets/images/'.$type.'/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = 2000;
        $config['max_width'] = 1500;
        $config['max_height'] = 1500;


		$this->load->library('upload', $config);
        $this->upload->initialize($config);
        if (!$this->upload->do_upload($field)) {
            $error = $this->upload->display_errors();
            $type = "error";
            $message = $error;
            // set_message($type, $message);
            //return $error;
            return FALSE;
            // uploading failed. $error will holds the errors.
        } else {
            $fdata = $this->upload->data();
            //$img_data ['path'] = $config['upload_path'] . $fdata['file_name'];
            $img_data ['path'] = $fdata['file_name'];
            return $img_data;
            // uploading successfull, now do your further actions
        }
        // $this->load->library('upload', $config);

        // if (!$this->upload->do_upload('upload_image')) {
            // $error = array('error' => $this->upload->display_errors());
			// return false;
        // } else {
            // $data = array('image_metadata' => $this->upload->data());
			// return true;
        // }
		
	}

	function images($type) {
		$data['images'] = $this->db->where('image_type', $type)->get('images')->result();
		$data['type'] = $type; //($type == 1) ? 'beginner_image':'';
		$this->load->view('admin/components/sidebar');
		$this->load->view('admin/pages/images',$data);
		$this->load->view('admin/components/footer');
	}
	
	public function memberships() {
		$data['memberships'] = $this->db->join('memberships','memberships.id = user.membership','left')->get('user')->result();
		
		$this->load->view('admin/components/sidebar');
		$this->load->view('admin/pages/memberships',$data);
		$this->load->view('admin/components/footer');
	}
	
}
