<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {

	public function index()
	{
	    $newpass = sha1("18421client");
		$data['client'] = $newpass;
		
		$data['username'] = '';
		$data['username_err'] = '';
		$data['password_err'] = '';
		$data['confirm_password_err'] = '';
		$data['membership'] = $_GET['membership'];
		$this->load->view('register', $data);
	}
	
}
