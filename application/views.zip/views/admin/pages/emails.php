<center>
<h1 class="voucher-header">EMAILS</h1><table style="width: 80%">

    <tr class="voucher-details voucher-welcome">
        <td style="text-align: center; padding: 2% 0;"><h3>Subject</h3></td>
        <td style="text-align: center; padding: 2% 0;"><h3>Name</h3></td>
        <td style="text-align: center; padding: 2% 0;"><h3>Email</h3></td>
        <td style="text-align: center; padding: 2% 0;"><h3>Message</h3></td>
    </tr>
    <?php foreach($emails as $email){ ?>
        <tr class="voucher-details voucher-welcome">
            <td style="text-align: center; padding: 2% 0;"><p><?php echo $email->subject;?></p></td>
            <td style="text-align: center; padding: 2% 0;"><p><?php echo $email->name;?></p></td>
            <td style="text-align: center; padding: 2% 0;"><p><?php echo $email->email;?></p></td>
            <td style="text-align: center; padding: 2% 0;"><p><?php echo $email->message;?></p></td>
        </tr>
    <?php } ?>
    </table>
</center>


