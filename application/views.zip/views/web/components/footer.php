

    <footer class="ftco-footer bg-light ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">GEMINI BEAUTY STUDIO</h2>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                <li class="ftco-animate"><a href="https://www.facebook.com/geminibeautysa/"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="https://www.instagram.com/geminibeautysa/"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4 ml-md-5">
              <h2 class="ftco-heading-2">Find Your Way</h2>
              <ul class="list-unstyled">
                <li><a href="<?php echo base_url('index');?>" class="py-2 d-block">Home</a></li>
                <li><a href="<?php echo base_url('about');?>" class="py-2 d-block">About</a></li>
                <li><a href="<?php echo base_url('portfolio');?>" class="py-2 d-block">Portfolio</a></li>
                <li><a href="<?php echo base_url('contact');?>" class="py-2 d-block">Contact Us</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-4">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Services we offer</h2>
              <div class="d-flex">
                <ul class="list-unstyled mr-l-5 pr-l-3 mr-4">
                <?php
                 $service_menu = "";
                  $services = $this->db->order_by('heading','asc')->get('products')->result();
                  foreach($services as $service){
                    $service_menu .= '<li><a href="'.base_url("web/services/{$service->id}").'" class="py-2 d-block">'.$service->heading.'</a>';
                  }
                  ?>
                  <?=$service_menu;?>
                </ul>
              </div>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Contact Us</h2>
              <div class="block-23 mb-3">
                <ul>
                  <li><span class="icon icon-map-marker"></span><span class="text"><a class="my-hover" href="https://www.google.co.za/maps/place/Buh-Rein+Estate/@-33.8245042,18.717011,17.05z/data=!4m5!3m4!1s0x1dcc54212bd9d607:0x5a6ba0bbc6cc7968!8m2!3d-33.8240888!4d18.7174154" target="_blank">32 Waterford Street Buh-rein Estate, East-Rural, Kraaifontein, 7570, Northern Suburbs, Cape town</a></span></li>
                  <li><a href="tel:0832602838"><span class="icon icon-phone"></span><span class="text">083 260 2838</span></a></li>
                  <li><a href="mailto:info@geminibeautystudio.co.za"><span class="icon icon-envelope"></span><span class="text">info@geminibeautystudio.co.za</span></a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

            <p>
        Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Designed and Developed by <a href="#" target="_blank">JNZ GROUP PTY LTD</a>
      </p>
          </div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="<?php echo base_url('assets/js/jquery.min.js');?>"></script>
  <script src="<?php echo base_url('assets/js/jquery-migrate-3.0.1.min.js');?>"></script>
  <script src="<?php echo base_url('assets/js/popper.min.js');?>"></script>
  <script src="<?php echo base_url('assets/js/bootstrap.min.js');?>"></script>
  <script src="<?php echo base_url('assets/js/jquery.easing.1.3.js');?>"></script>
  <script src="<?php echo base_url('assets/js/jquery.waypoints.min.js');?>"></script>
  <script src="<?php echo base_url('assets/js/jquery.stellar.min.js');?>"></script>
  <script src="<?php echo base_url('assets/js/owl.carousel.min.js');?>"></script>
  <script src="<?php echo base_url('assets/js/jquery.magnific-popup.min.js');?>"></script>
  <script src="<?php echo base_url('assets/js/aos.js');?>"></script>
  <script src="<?php echo base_url('assets/js/jquery.animateNumber.min.js');?>"></script>
  <script src="<?php echo base_url('assets/js/bootstrap-datepicker.js');?>"></script>
  <script src="<?php echo base_url('assets/js/scrollax.min.js');?>"></script>
  <script src="<?php echo base_url('assets/js/main.js');?>"></script>
  
    </body>
</html>
