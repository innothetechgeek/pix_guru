	
	<div class="hero-wrap js-fullheight" style="background-image: url('assets/images/bg_1.jpg');">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-center">
          
          <div class="col-md-11 ftco-animate text-center">
             <img class="my-logo" src="http://geminibeautystudio.co.za/assets/images/logo.png" >
            <!--<h1>Welcome</h1>-->
            <!--<h2><span>Lash, Brow and Nails</span></h2>-->
          </div>
          <div class="mouse">
			<a href="#" class="mouse-icon">
				<div class="mouse-wheel"><span class="ion-ios-arrow-down"></span></div>
			</a>
		</div>
        </div>
      </div>
    </div>

    <div class="goto-here"></div>
    
    <section class="ftco-section ftco-product">
    	<div class="container">
			<div class="row justify-content-center mb-3 pb-3">
				<div class="col-md-12 heading-section text-center ftco-animate">
					<h1 class="big">PORTFOLIO</h1>
					<h2 class="mb-4">VIEW OUR GALLERY</h2>
				</div>
				<a href="<?php echo base_url('portfolio');?>" class="btn btn-gallery" style="z-index: 100">VIEW OUR GALLERY</a>  
			</div>
        
    		<!--<div class="row">-->
    		<!--	<div class="col-md-12">-->
    		<!--		<div class="product-slider owl-carousel ftco-animate">-->
    		<!--			<div class="item">-->
		    <!--				<div class="product">-->
		    <!--					<a href="#" class="img-prod"><img class="img-fluid" src="assets/images/product-1.jpg" alt="Nail Services">-->
		    <!--						<span class="status">Nail Services</span>-->
		    <!--					</a>-->
		    <!--					<div class="text pt-3 px-3">-->
		    <!--						<div class="d-flex">-->
		    <!--							<div class="pricing">-->
			   <!-- 							<p class="price"><span>We offer a wide range</span></p>-->
			   <!-- 						</div>-->
			   <!-- 						<div class="rating">-->
			   <!-- 							<p class="text-right">-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 							</p>-->
			   <!-- 						</div>-->
		    <!--						</div>-->
		    <!--					</div>-->
		    <!--				</div>-->
	    	<!--			</div>-->
	    	<!--			<div class="item">-->
		    <!--				<div class="product">-->
		    <!--					<a href="#" class="img-prod"><img class="img-fluid" src="assets/images/product-2.jpg" alt="Make Up Services">-->
		    <!--						<span class="status">Make-Up Services</span>-->
		    <!--					</a>-->
		    <!--					<div class="text pt-3 px-3">-->
		    <!--						<div class="d-flex">-->
		    <!--							<div class="pricing">-->
				  <!--  						<p class="price"><span>Make Up Services upon request</span></p>-->
				  <!--  					</div>-->
				  <!--  					<div class="rating">-->
			   <!-- 							<p class="text-right">-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 							</p>-->
			   <!-- 						</div>-->
			   <!-- 					</div>-->
		    <!--					</div>-->
		    <!--				</div>-->
	    	<!--			</div>-->
	    	<!--			<div class="item">-->
		    <!--				<div class="product">-->
		    <!--					<a href="#" class="img-prod"><img class="img-fluid" src="assets/images/product-3.jpg" alt="Microblading Services">-->
		    <!--						<span class="status">Microblading Services</span>-->
		    <!--					</a>-->
		    <!--					<div class="text pt-3 px-3">-->
		    <!--						<div class="d-flex">-->
		    <!--							<div class="pricing">-->
				  <!--  						<p class="price"><span>Artist apply each hair-stroke with a handheld micro-blade</span></p>-->
				  <!--  					</div>-->
				  <!--  					<div class="rating">-->
			   <!-- 							<p class="text-right">-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 							</p>-->
			   <!-- 						</div>-->
			   <!-- 					</div>-->
		    <!--					</div>-->
		    <!--				</div>-->
	    	<!--			</div>-->
	    	<!--			<div class="item">-->
		    <!--				<div class="product">-->
		    <!--					<a href="#" class="img-prod"><img class="img-fluid" src="assets/images/product-1.jpg" alt="Nail Services">-->
		    <!--						<span class="status">Nail Services</span>-->
		    <!--					</a>-->
		    <!--					<div class="text pt-3 px-3">-->
		    <!--						<div class="d-flex">-->
		    <!--							<div class="pricing">-->
			   <!-- 							<p class="price"><span>We offer a wide range</span></p>-->
			   <!-- 						</div>-->
			   <!-- 						<div class="rating">-->
			   <!-- 							<p class="text-right">-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 							</p>-->
			   <!-- 						</div>-->
		    <!--						</div>-->
		    <!--					</div>-->
		    <!--				</div>-->
	    	<!--			</div>-->
	    	<!--			<div class="item">-->
		    <!--				<div class="product">-->
		    <!--					<a href="#" class="img-prod"><img class="img-fluid" src="assets/images/product-2.jpg" alt="Make Up Services">-->
		    <!--						<span class="status">Make-Up Services</span>-->
		    <!--					</a>-->
		    <!--					<div class="text pt-3 px-3">-->
		    <!--						<div class="d-flex">-->
		    <!--							<div class="pricing">-->
				  <!--  						<p class="price"><span>Make Up Services upon request</span></p>-->
				  <!--  					</div>-->
				  <!--  					<div class="rating">-->
			   <!-- 							<p class="text-right">-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 							</p>-->
			   <!-- 						</div>-->
			   <!-- 					</div>-->
		    <!--					</div>-->
		    <!--				</div>-->
	    	<!--			</div>-->
	    	<!--			<div class="item">-->
		    <!--				<div class="product">-->
		    <!--					<a href="#" class="img-prod"><img class="img-fluid" src="assets/images/product-3.jpg" alt="Microblading Services">-->
		    <!--						<span class="status">Microblading Services</span>-->
		    <!--					</a>-->
		    <!--					<div class="text pt-3 px-3">-->
		    <!--						<div class="d-flex">-->
		    <!--							<div class="pricing">-->
				  <!--  						<p class="price"><span>Artist apply each hair-stroke with a handheld micro-blade</span></p>-->
				  <!--  					</div>-->
				  <!--  					<div class="rating">-->
			   <!-- 							<p class="text-right">-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 								<span class="ion-ios-star-outline"></span>-->
			   <!-- 							</p>-->
			   <!-- 						</div>-->
			   <!-- 					</div>-->
		    <!--					</div>-->
		    <!--				</div>-->
	    	<!--			</div>-->
    		<!--		</div>-->
    		<!--	</div>-->
    		<!--</div>-->
    	</div>
    </section>

    <section class="ftco-section ftco-no-pb ftco-no-pt bg-light">
			<div class="container">
				<div class="row">
					<div class="col-md-5 p-md-5 img img-2 d-flex justify-content-center align-items-center" style="background-image: url(assets/images/bg_2.jpeg);">
					</div>
					<div class="col-md-7 py-5 wrap-about pb-md-5 ftco-animate">
	          <div class="heading-section-bold mb-5 mt-md-5">
	          	<div class="ml-md-0">
		            <h2 class="mb-4">About Gemini Beauty Studio</span></h2>
	            </div>
	          </div>
	          <div class="pb-md-5">
        	       <p>Welcome to my page! Gemini Beauty Studio is a home-based Beauty, Lash, Brow & Nail Studio in Buh Rein Estate. Online bookings with flexible hours. Gift vouchers can be purchased online. 15 years in the industry and love every moment.</p>
              </div>  
	          
	          <div class="heading-section-bold mb-5 mt-md-5">
	          	<div class="ml-md-0">
		            <h2 class="mb-4">Mission statement</span></h2>
	            </div>
	          </div>
	          <div class="pb-md-5">
        	       <p>
                        Where you experience a family atmosphere where you come as a guest and leave as friends. Client relationships from 15 years ago. 
                        Building a small business by striving to exceed my clients' expectations. Qualified and experienced in diversity in all aspects 
                        of the nail and beauty industry. To serve customers with integrity by being loyal to them, the business, and myself.
                    </p>     
       <!--                     To give superior customer service consistently with a happy relentless attitude whole standing within an affordable budget for families.-->
							<!--<p>White tippex used as french white nail polish in the class room as a result of detention letters. It followed with school hostel “pamper parties” and always being late for a school dance. Then in grade 11, I started job shadowing for a school subject in a hair and beauty salon (Tosca in Tyger Valley Center). It followed to a school holiday and occasional weekend casual job.<br><br>-->
							<!--I met my first nail educator Erika Breytenbach at Caprice Academy in January 2005 where I completed a Acrylic Nail Education Course conducted by EzFlow Nail Systems.-->
							<!-- Completed a course in Bio Sculpture Gel Nail Care 2006. -->
							<!--Through my first job at Dream nails March 2005, I completed a course in all nail systems and Qualified through Nail System International in September 2007. <br><br>-->
							<!--In January 2009 I met Sanmarie Botha and completed pedicures and manicures in Achievement award of advanced Spa Ritual Training at Logica Beauty Supplies Working at Ooh- La-La Nail Bar.-->
							<!--My Job after that followed at Sorbet Group and training in Gelish, Acrylic, manicure & pedicure via Harmony. Dermalogica and Environ skin care training and exam.-->
							<!--In 2010 I worked at Dion Lifestyle Hair Nail and Beauty studio. <br><br>-->
							<!--I took my work experience and returned to my first educator Erika Breytenbach and worked for her daughter, Bertha Shannon Leonard in 2011 (SAQA qualified assessor and moderator). -->
							<!--I worked for her for 5 years with the best work experience and training experience in my career. Nailsforu distributors, Capri Beauty an Capri Academy Clinic. Full Nail technology training and exam (Nailsforu).</p>-->
						</div>
					</div>
				</div>
			</div>
		</section>

    <section class="ftco-section ftco-section-more img" style="background-image: url(assets/images/bg_5.jpg);">
    	<div class="container">
    		<div class="row justify-content-center mb-3 pb-3">
          <div class="col-md-12 heading-section ftco-animate">
          	<h2>BE YOU</h2>
          </div>
        </div>
    	</div>
    </section>



    <section class="ftco-section contact-section bg">
      <div class="container">
        <div class="row block-9">
          <div class="col-md-6 order-md-last d-flex">
            <form action="<?php echo base_url('web/mail');?>" method="post" class="contact-form">
              <div class="form-group">
                <input type="text" class="form-control" placeholder="Your Name" name="name">
              </div>
              <div class="form-group">
                <input type="text" class="form-control" placeholder="Your Email" name="email">
              </div>
              <div class="form-group">
                <input type="text" class="form-control" placeholder="Subject" name="subject">
              </div>
              <div class="form-group">
                <textarea name="message" id="" cols="30" rows="7" class="form-control" placeholder="Message"></textarea>
              </div>
              <div class="form-group">
                <input type="submit" value="Send Message" class="btn btn-primary py-3 px-5">
              </div>
            </form>
          
          </div>

          <div class="col-md-6 d-flex">
          	<div class="info p-4"><br><br>
          		<div class="row">
	          		<div class="col-md-3"><span class="ion-md-business details"></span></div>
	          		<div class="col-md-9"><h5>Visit Us</h5><p><a class="my-hover" href="https://www.google.co.za/maps/place/Buh-Rein+Estate/@-33.8245042,18.717011,17.05z/data=!4m5!3m4!1s0x1dcc54212bd9d607:0x5a6ba0bbc6cc7968!8m2!3d-33.8240888!4d18.7174154" target="_blank">32 Waterford Street Buh-rein Estate, East-Rural, Kraaifontein, 7570, Northern Suburbs, Cape town</a></p></div>
          		</div><hr>
          		<div class="row">
	          		<div class="col-md-3"><span class="ion-ios-mail details"></span></div>
	          		<div class="col-md-9"><h5>Mail Us</h5><p><a style="color: #222" href="mailto:info@geminbeutystudio.co.za">info@geminbeutystudio.co.za</a></p></div>
          		</div><hr>
          		<div class="row">
	          		<div class="col-md-3"><span class="ion-ios-call details"></span></div>
	          		<div class="col-md-9"><h5>Call Us</h5><p><a style="color: #222" href="tel:0832602838">083 260 2838</a></p></div>
          		</div>
	         </div>
          </div>
        </div>
      </div>
    </section>

	<section class=" ftco-section-parallax ftco-services img" style="padding: 5% 0; background-image: url(<?php echo base_url('assets/images/gift.jpg');?>);">
      <div class="align-items-center">
        <div class="container">
          <div class="row">
            <div class="gift text-center ftco-animate">
                  <h2 style="color: #fff">GIFT VOUCHER OPTIONS</h2><br />
                  <?php
				    $vouchers = $this->db->where('status',1)->get('vouchers')->result();
                    foreach ($vouchers as $voucher) {   
						$option = ($voucher->type == 'custom')? $voucher->title.' (Custom)':$voucher->title.' (R'.$voucher->price.')';
						echo '<div class="voucher-details welcome">
							  <a href="'.base_url('web/voucher/'.$voucher->id).'"><span>'.$option.'</span></a><br /><br />
							  </div>';
					}
                    ?>
            </div>
          </div>
        </div>
      </div>
    </section>
   

    <!--<section class="ftco-section bg-pink ftco-services">-->
    <!--	<div class="container">-->
    <!--		<div class="row justify-content-center mb-3 pb-3">-->
    <!--      <div class="col-md-12 heading-section text-center ftco-animate">-->
    <!--        <h1 class="big">Info</h1>-->
    <!--        <h2>What we gaurantee</h2>-->
    <!--      </div>-->
    <!--    </div>-->
    <!--    <div class="row">-->
    <!--      <div class="col-md-4 text-center d-flex align-self-stretch ftco-animate">-->
    <!--        <div class="media block-6 services">-->
    <!--          <div class="icon d-flex justify-content-center align-items-center mb-4">-->
    <!--        		<span class="ion-md-medal"></span>-->
    <!--          </div>-->
    <!--          <div class="media-body">-->
    <!--            <h3 class="heading">Quality Service</h3>-->
    <!--            <p>At Gemini Beauty Studio we provide only the best quality service to our customers.</p>-->
    <!--          </div>-->
    <!--        </div>      -->
    <!--      </div>-->
    <!--      <div class="col-md-4 text-center d-flex align-self-stretch ftco-animate">-->
    <!--        <div class="media block-6 services">-->
    <!--          <div class="icon d-flex justify-content-center align-items-center mb-4">-->
    <!--        		<span class="ion-ios-checkbox"></span>-->
    <!--          </div>-->
    <!--          <div class="media-body">-->
    <!--            <h3 class="heading">Products</h3>-->
    <!--            <p>We sell a variety of products in store!</p>-->
    <!--          </div>-->
    <!--        </div>    -->
    <!--      </div>-->
    <!--      <div class="col-md-4 text-center d-flex align-self-stretch ftco-animate">-->
    <!--        <div class="media block-6 services">-->
    <!--          <div class="icon d-flex justify-content-center align-items-center mb-4">-->
    <!--        		<span class="ion-ios-infinite"></span>-->
    <!--          </div>-->
    <!--          <div class="media-body">-->
    <!--            <h3 class="heading">Ultra-Modern</h3>-->
    <!--            <p>Our team are up to minute with the most popular and sheek styles available! </p>-->
    <!--          </div>-->
    <!--        </div>      -->
    <!--      </div>-->
    <!--    </div>-->
    <!--	</div>-->
    <!--</section>-->
		
		<!--<section class="ftco-section-parallax">-->
  <!--    <div class="parallax-img d-flex align-items-center">-->
  <!--      <div class="container">-->
  <!--        <div class="row d-flex justify-content-center py-5">-->
  <!--          <div class="col-md-7 text-center heading-section ftco-animate">-->
  <!--          	<h1 class="big">Subscribe</h1>-->
  <!--            <h2>JOIN OUR WEEKLY NEWSLETTERS</h2>-->
  <!--            <div class="row d-flex justify-content-center mt-5">-->
  <!--              <div class="col-md-8">-->
  <!--                <form action="#" class="subscribe-form">-->
  <!--                  <div class="form-group d-flex">-->
  <!--                    <input type="text" class="form-control" placeholder="Enter email address">-->
  <!--                    <input type="submit" value="Subscribe" class="submit px-3">-->
  <!--                  </div>-->
  <!--                </form>-->
  <!--              </div>-->
  <!--            </div>-->
  <!--          </div>-->
  <!--        </div>-->
  <!--      </div>-->
  <!--    </div>-->
  <!--  </section>-->

