    <div class="hero-wrap hero-bread" style="background-image: url(<?php echo base_url('assets/images/gift.jpg'); ?>);">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-0 bread" style="color: #fff"><b>GIFT VOUCHER OPTIONS</b></h1>
          </div>
        </div>
      </div>
    </div>



    <section class="ftco-section contact-section bg">
      <div class="container">
        <div class="row block-9">
          <div class="col-md-6 order-md-last d-flex">
            <h2>Sorry, Your Order has been cancelled.</h2>
          </div>

          <div class="col-md-6 d-flex">
            <div class="info p-4"><br><br>
              <div class="row">
                <img src="<?php echo base_url('assets/images/gift-wrap.png');?>" alt="gemini beauty studio" style="width: 100%">
              </div>
           </div>
          </div>
        </div>
      </div>
    </section>
